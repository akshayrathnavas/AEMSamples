use(function()
		{
	var returnData={};
	var rootPage =currentPage.getAbsoluteParent(2);
	
	if(rootPage==null) rootPage=currentPage;
	
	returnData.navigationList=rootPage.listChildren();
	
	returnData.homePagePath=rootPage.getPath();
	
	
	returnData.hello = "World"
		
		return returnData;
	
		}
)