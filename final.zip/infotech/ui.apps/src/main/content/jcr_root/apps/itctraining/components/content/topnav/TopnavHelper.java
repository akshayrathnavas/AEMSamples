package apps.itctraining.components.content.topnav;

import java.util.Iterator;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;

public class TopnavHelper extends WCMUsePojo{

	Page rootPage;
	
	
	
	@Override
	public void activate() throws Exception {
		rootPage=getCurrentPage().getAbsoluteParent(2);
	if(rootPage==null)rootPage=getCurrentPage();

			
	}
	
	public Iterator<Page> getNavigationList() {
		return rootPage.listChildren();
	}
    
	public String getHomePagePath() {
		return rootPage.getPath();
	}
	
}