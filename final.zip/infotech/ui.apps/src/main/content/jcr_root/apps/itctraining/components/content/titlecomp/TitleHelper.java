package apps.itctraining.components.content.titlecomp;

import com.adobe.cq.sightly.WCMUsePojo;

public class TitleHelper extends WCMUsePojo{

	@Override
	public void activate() throws Exception {

	
	}

	
    
}