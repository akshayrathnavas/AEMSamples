package apps.itctraining.components.content.listcomponent;


import java.util.Iterator;

import com.adobe.cq.sightly.WCMUsePojo;
import com.day.cq.wcm.api.Page;

public class ListHelper extends WCMUsePojo{
	
	String rootPath;
	boolean hasData;
	Iterator<Page> children;
	String listHeader;

	@Override
	public void activate() throws Exception {
		
		listHeader=getProperties().get("listHeader","list");

		//read the root path

		rootPath=getProperties().get("rootPath","");
		hasData=rootPath.length() > 0;
		
		//if rootpath is available get children
		
		Page rootPage= getPageManager().getPage(rootPath);
		
		if(rootPage!=null) {
			children=rootPage.listChildren();
			if(children==null) hasData=false;
			
		}
		else {
			hasData=false;
			
		}
		
		}
		public boolean hasData() {
			return hasData;
		}
		public Iterator<Page> getListItems(){
			return children;
			
		}
		//if no children then show message
		
	
	
		public String getListHeader() {
			return listHeader;

		}
}