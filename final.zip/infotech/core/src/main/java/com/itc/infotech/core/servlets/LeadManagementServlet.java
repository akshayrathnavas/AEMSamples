package com.itc.infotech.core.servlets;

import java.io.IOException;

import javax.servlet.Servlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.itc.infotech.core.business.LeadManagementService;
import com.itc.infotech.core.models.LeadData;

@Component(service=Servlet.class,property= {"sling.servlet.paths="+"/itc/leads",
					 "sling.servlet.methods=get",
					 "sling.servlet.methods=post"})
public class LeadManagementServlet extends SlingAllMethodsServlet {
	
	@Reference
	LeadManagementService leadManagementService;
	
	public void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		response.getWriter().println("Saving Leads At:"+leadManagementService.getLeadsPath());
			
		}
	
	
	public void doPost(SlingHttpServletRequest request, SlingHttpServletResponse response) throws IOException {
		LeadData lead= new LeadData(request.getParameter("leadName"),request.getParameter("leadEmail"));
		response.getWriter().println(lead.toString());
		leadManagementService.addLead(lead);
		
	}

}
