package com.itc.infotech.core.listeners;

import java.util.EventListener;

import javax.jcr.PathNotFoundException;
import javax.jcr.Property;
import javax.jcr.RepositoryException;
import javax.jcr.Session;
import javax.jcr.UnsupportedRepositoryOperationException;
import javax.jcr.observation.Event;
import javax.jcr.observation.EventIterator;
import javax.jcr.observation.ObservationManager;

import org.apache.sling.api.resource.LoginException;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

@Component
public class LeadCountObserver implements javax.jcr.observation.EventListener{

	
	@Reference
	SlingRepository slingRepository;
	
	Session session;
	ObservationManager observationManager;
	@Activate
	protected void activate()
	{
		
			try {
				session=slingRepository.loginService("trainingService", null);
				observationManager = session.getWorkspace().getObservationManager();
				observationManager.addEventListener(this, Event.PROPERTY_CHANGED|Event.PROPERTY_ADDED, "/", true, null, null, true);
			} catch (javax.jcr.LoginException e) {
				e.printStackTrace();
			} catch (UnsupportedRepositoryOperationException e) {
				e.printStackTrace();
			} catch (RepositoryException e) {
				e.printStackTrace();
			}
		
	
	}
	
	@Deactivate
	protected void deactivate() {
		try {
			if(observationManager !=null) {
				observationManager.removeEventListener(this);
			}
			
		if(session!=null)session.logout();
		}
		catch(RepositoryException e) {
		e.printStackTrace();
		}
		
		}

	@Override
	public void onEvent(EventIterator events) {
		while(events.hasNext()) {
			Event currentEvent =events.nextEvent();
			try {
				Property currentProperty=session.getProperty(currentEvent.getPath());
				if(currentProperty.getName().equals("count")) {
					//if(currentProperty.getParent().setProperty("lead-status","critical"));
					session.save();
					
					
				}
			} catch (PathNotFoundException e) {
				e.printStackTrace();
			} catch (RepositoryException e) {
				e.printStackTrace();
			}
		}

		
	}

}
