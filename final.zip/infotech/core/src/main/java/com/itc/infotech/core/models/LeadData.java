package com.itc.infotech.core.models;

public class LeadData {
	String leadName;
	String leadEmail;
	
	public LeadData(String leadName, String leadEmail) {
		this.leadName=leadName;
		this.leadEmail=leadEmail;
	}
	public String getLeadName() {
		return leadName;
	}
	public String getLeadEmail() {
		return leadEmail;
	}
	@Override
	public String toString() {
		return "LeadData [leadName=" + leadName + ", leadEmail=" + leadEmail + "]";
	}

}
