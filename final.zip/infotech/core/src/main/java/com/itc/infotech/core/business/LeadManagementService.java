package com.itc.infotech.core.business;

import java.util.List;

import com.itc.infotech.core.models.LeadData;

public interface LeadManagementService {
	
	public String getLeadsPath();
	public void addLead(LeadData leadData);
	public List<LeadData> getLeads();
	

}
