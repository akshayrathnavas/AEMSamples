package com.itc.infotech.core.business;

import java.util.List;

import javax.jcr.LoginException;
import javax.jcr.Node;
import javax.jcr.RepositoryException;
import javax.jcr.Session;

import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.AttributeType;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.commons.jcr.JcrUtil;
import com.itc.infotech.core.models.LeadData;
@Designate(ocd=LeadManagementServiceImpl.Config.class)
@Component(service = LeadManagementService.class)
public class LeadManagementServiceImpl implements LeadManagementService {
	
	
private Logger log = LoggerFactory.getLogger(getClass());	
String  leadRootPath;

@Reference
SlingRepository slingRepo;

Session session;


	@ObjectClassDefinition(name="Lead Management Service")
	public @interface Config {

		@AttributeDefinition(name = "Lead Path", type = AttributeType.STRING)
		public String lead_path() default "/etc/temp";

	}
	@Activate
	protected void activate(Config config) {
		 leadRootPath = config.lead_path();
	}

	@Override
	public String getLeadsPath() {

		return leadRootPath;
	}

	@Override
	public void addLead(LeadData leadData) {
		try {
			 session=slingRepo.loginService("trainingService",null);
			 log.info("session created");
			Node rootNode= session.itemExists(leadRootPath)?
					rootNode= session.getNode(leadRootPath):
					JcrUtil.createPath(leadRootPath, "sling:Folder", session);
			String nodeName= leadData.getLeadName().replaceAll("\\s+","").toLowerCase();
			Node leadNode=rootNode.hasNode(nodeName)?
					rootNode.getNode(nodeName):
						rootNode.addNode(nodeName);
					leadNode.setProperty("lead-name", leadData.getLeadName());
					leadNode.setProperty("lead-email", leadData.getLeadEmail());
					session.save();
					log.info("session saved at"+leadNode.getPath());
		} catch (LoginException e) {
		log.error("Login Error",e);
			
		} catch (RepositoryException e) {
			log.error("Repo Error",e);
			
		} finally {
			if(session != null) session.logout();
		}
		
	}

	@Override
	public List<LeadData> getLeads() {
		// TODO Auto-generated method stub
		return null;
	}

}
