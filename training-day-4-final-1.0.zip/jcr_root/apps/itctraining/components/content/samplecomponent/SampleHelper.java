package apps.itctraining.components.content.samplecomponent;

import com.adobe.cq.sightly.WCMUsePojo;

public class SampleHelper extends WCMUsePojo {

	String sampleText;

	@Override
	public void activate() throws Exception {

		sampleText=getProperties().get("sampleName","list");
		
		

		
	}
	
	
	public String rtName() {
		if(sampleText!=null) {
			return sampleText;
		}
		else
			return "No Text Available";

	}
   
}